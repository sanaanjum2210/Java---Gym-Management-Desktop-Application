/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Sana Anjum
 */
public class utility {
    private int electricity,water,rent;
    private String month;
    public utility(int electricity,int water,int rent, String month)
    {
        this.electricity=electricity;
        this.water=water;
        this.rent=rent;
        this.month=month;
    }
    utility() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    public int get_electricity()
    {
        return electricity;
    }
    public int get_water()
    {
        return water;
    }
    public int get_rent()
    {
        return rent;
    }
    
    public String get_month()
    {
        return month;
    }
    
}

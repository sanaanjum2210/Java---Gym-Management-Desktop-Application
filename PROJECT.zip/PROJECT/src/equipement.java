/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Sana Anjum
 */
public class equipement {
     private int available_pieces,defected_pieces,price;
    private String product_id,product_name;
    public equipement(int available_pieces,int defected_pieces,int price, String product_id,String product_name)
    {
        this.product_id=product_id;
        this.product_name=product_name;
        this.available_pieces=available_pieces;
        this.defected_pieces=defected_pieces;
        this.price=price;
    }

    equipement(int aInt, int aInt0, int aInt1, String string) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

   
  
 
    public String get_productid()
    {
        return product_id;
    }
    public String get_productname()
    {
        return product_name;
    }
    public int get_available()
    {
        return available_pieces;
    }
    public int get_defected()
    {
        return defected_pieces;
        
    }
    public int getprice()
    {
        return price;
    }

   
    
}

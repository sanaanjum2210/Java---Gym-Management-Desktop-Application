/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Sana Anjum
 */
class User {
    private int member_id,age;
    private String firstname,lastname,username,password_member,mobileno,gender;
    public User(int member_id, int age, String firstname,String lastname,String username,String password_member,String mobileno,String gender)
    {
        this.member_id=member_id;
        this.age=age;
        this.firstname=firstname;
        this.lastname=lastname;
        this.username=username;
        this.password_member=password_member;
        this.mobileno=mobileno;
        this.gender=gender;
    }

    User() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    public int getmember_id()
     {
          return member_id;      
     }
    public int getage()
    {
        return age;
    }
    public String getfirstname()
    {
        return firstname;
    }
     public String getlastname()
    {
        return lastname;
    }
      public String getusername()
    {
        return username;
    }
      public String getpassword_member()
      {
          return password_member;
      }
      public String getmobileno()
    {
        return mobileno;
    }
     public String getgender()
    {
        return gender;
    }
      
       
}

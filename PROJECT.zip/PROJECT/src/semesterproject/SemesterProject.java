/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package semesterproject;
import java.sql.*;
/**
 *
 * @author Sana Anjum
 */
public class SemesterProject {
        private static final String USERNAME="root";
        private static final String PASSWORD="";
         private static final String CONN_STRING=
                 "jdbc:mysql://localhost:3306/semesterproject";
         
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Connection conn = null;
        try{
            conn = DriverManager.getConnection(CONN_STRING,USERNAME,PASSWORD);
            System.out.println("connected");
           
        } catch (SQLException e){
               System.err.println(e);
        }
    }
    
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Sana Anjum
 */
public class staff {
      private int staff_id;
      private String staffname,gender,designation,address,salary,mobileno;
      
       public staff(int staff_id,String staffname,String gender,String designation,String address,String salary,String mobileno)
    {
       this.staff_id=staff_id;
       this.staffname=staffname;
       this.gender=gender;
       this.designation=designation;
       this.address=address;
       this.salary=salary;
       this.mobileno=mobileno;
    }

    staff() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    public int getstaff_id()
     {
          return staff_id;      
     }
    public String getstaffname()
    {
        return staffname;
    }
     public String getgender()
    {
        return gender;
    }
     public String getdesignation()
    {
        return designation;
    }
      public String getaddress()
    {
        return address;
    }
      public String getsalary()
      {
          return salary;
      }
      public String getmobileno()
    {
        return mobileno;
    }
    
      
}
